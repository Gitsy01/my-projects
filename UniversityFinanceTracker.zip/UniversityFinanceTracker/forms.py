from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField, SelectField, DecimalField, DateField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length, Optional, NumberRange
from datetime import date
from models import User, Department, BudgetCategory, FiscalYear

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different one.')

class DepartmentForm(FlaskForm):
    name = StringField('Department Name', validators=[DataRequired(), Length(max=100)])
    code = StringField('Department Code', validators=[DataRequired(), Length(max=10)])
    description = TextAreaField('Description', validators=[Optional()])
    head_id = SelectField('Department Head', coerce=int, validators=[Optional()])
    submit = SubmitField('Save Department')

class BudgetCategoryForm(FlaskForm):
    name = StringField('Category Name', validators=[DataRequired(), Length(max=100)])
    code = StringField('Category Code', validators=[DataRequired(), Length(max=10)])
    description = TextAreaField('Description', validators=[Optional()])
    submit = SubmitField('Save Category')

class FiscalYearForm(FlaskForm):
    name = StringField('Fiscal Year Name', validators=[DataRequired(), Length(max=100)])
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    is_active = BooleanField('Is Active')
    submit = SubmitField('Save Fiscal Year')
    
    def validate_end_date(self, end_date):
        if end_date.data <= self.start_date.data:
            raise ValidationError('End date must be after start date.')

class BudgetForm(FlaskForm):
    amount = DecimalField('Budget Amount', validators=[DataRequired(), NumberRange(min=0)], places=2)
    description = TextAreaField('Description', validators=[Optional()])
    department_id = SelectField('Department', coerce=int, validators=[DataRequired()])
    fiscal_year_id = SelectField('Fiscal Year', coerce=int, validators=[DataRequired()])
    category_id = SelectField('Budget Category', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Budget')

class ExpenseForm(FlaskForm):
    amount = DecimalField('Expense Amount', validators=[DataRequired(), NumberRange(min=0)], places=2)
    description = TextAreaField('Description', validators=[Optional()])
    date = DateField('Expense Date', validators=[DataRequired()], default=date.today)
    receipt_number = StringField('Receipt Number', validators=[Optional(), Length(max=50)])
    department_id = SelectField('Department', coerce=int, validators=[DataRequired()])
    budget_id = SelectField('Budget', coerce=int, validators=[DataRequired()])
    category_id = SelectField('Expense Category', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Expense')
    
    def validate_date(self, date_field):
        if date_field.data > date.today():
            raise ValidationError('Expense date cannot be in the future.')

class BudgetAdjustmentForm(FlaskForm):
    budget_id = SelectField('Budget', coerce=int, validators=[DataRequired()])
    amount = DecimalField('Adjustment Amount', validators=[DataRequired()], places=2)
    justification = TextAreaField('Justification', validators=[DataRequired()])
    submit = SubmitField('Request Adjustment')

class ReportFilterForm(FlaskForm):
    fiscal_year_id = SelectField('Fiscal Year', coerce=int, validators=[Optional()])
    department_id = SelectField('Department', coerce=int, validators=[Optional()])
    category_id = SelectField('Category', coerce=int, validators=[Optional()])
    start_date = DateField('Start Date', validators=[Optional()])
    end_date = DateField('End Date', validators=[Optional()])
    submit = SubmitField('Generate Report')
    
    def validate_end_date(self, end_date):
        if self.start_date.data and end_date.data and end_date.data < self.start_date.data:
            raise ValidationError('End date must be after start date.')
