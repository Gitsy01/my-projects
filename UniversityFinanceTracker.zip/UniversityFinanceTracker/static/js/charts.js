/**
 * Creates a Chart.js chart with the given data
 * @param {string} elementId - The ID of the canvas element
 * @param {string} type - The type of chart ('bar', 'line', 'pie', 'doughnut', etc.)
 * @param {object} data - The data object for the chart
 * @param {object} options - Additional options for the chart
 */
function createChart(elementId, type, data, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return;
    
    // Set default options based on chart type
    let defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        
                        // Format the value as currency
                        if (context.parsed.y !== undefined) {
                            label += '$' + context.parsed.y.toFixed(2);
                        } else if (context.parsed !== undefined && type === 'doughnut') {
                            label += '$' + context.parsed.toFixed(2);
                        }
                        return label;
                    }
                }
            }
        }
    };
    
    // Add specific options for bar charts
    if (type === 'bar' || type === 'line') {
        defaultOptions.scales = {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '$' + value;
                    }
                }
            }
        };
    }
    
    // Merge the provided options with default options
    const chartOptions = Object.assign({}, defaultOptions, options);
    
    // Create and return the chart
    return new Chart(canvas, {
        type: type,
        data: data,
        options: chartOptions
    });
}

/**
 * Loads chart data from the API and creates a chart
 * @param {string} elementId - The ID of the canvas element
 * @param {string} chartType - The type of chart to create
 * @param {string} dataType - The type of data to request from API
 * @param {string} fiscalYearId - Optional fiscal year ID to filter data
 */
function loadChartData(elementId, chartType, dataType, fiscalYearId = null) {
    let url = `/reports/api/chart_data?type=${dataType}`;
    if (fiscalYearId) {
        url += `&fiscal_year_id=${fiscalYearId}`;
    }
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            createChart(elementId, chartType, data);
        })
        .catch(error => {
            console.error('Error loading chart data:', error);
            // Display an error message in the chart container
            const canvas = document.getElementById(elementId);
            if (canvas) {
                const container = canvas.parentElement;
                const errorMessage = document.createElement('div');
                errorMessage.className = 'alert alert-danger';
                errorMessage.innerHTML = '<i class="fas fa-exclamation-circle me-2"></i> Error loading chart data';
                container.replaceChild(errorMessage, canvas);
            }
        });
}

/**
 * Creates a budget utilization gauge chart
 * @param {string} elementId - The ID of the canvas element
 * @param {number} value - The utilization percentage (0-100)
 * @param {number} maxValue - The maximum value (default: 100)
 */
function createGaugeChart(elementId, value, maxValue = 100) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return;
    
    // Determine color based on utilization percentage
    let color = '#28a745'; // success/green
    if (value > 90) {
        color = '#dc3545'; // danger/red
    } else if (value > 70) {
        color = '#ffc107'; // warning/yellow
    }
    
    return new Chart(canvas, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [value, maxValue - value],
                backgroundColor: [color, '#e9ecef'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '80%',
            circumference: 180,
            rotation: 270,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: false
                }
            },
            animation: {
                animateRotate: true,
                animateScale: false
            }
        }
    });
}

/**
 * Updates chart data periodically for real-time dashboards
 * @param {string} elementId - The ID of the canvas element
 * @param {string} dataType - The type of data to request from API
 * @param {number} interval - The refresh interval in milliseconds (default: 30000 ms / 30 seconds)
 */
function setupChartRefresh(elementId, dataType, interval = 30000) {
    // Load initial chart data
    loadChartData(elementId, 'bar', dataType);
    
    // Set up periodic refresh
    setInterval(() => {
        // Get the chart instance from the canvas
        const canvas = document.getElementById(elementId);
        if (!canvas) return;
        
        const chartInstance = Chart.getChart(canvas);
        if (!chartInstance) return;
        
        // Fetch updated data
        fetch(`/reports/api/chart_data?type=${dataType}`)
            .then(response => response.json())
            .then(data => {
                // Update chart data
                chartInstance.data.labels = data.labels;
                chartInstance.data.datasets.forEach((dataset, i) => {
                    dataset.data = data.datasets[i].data;
                });
                
                // Redraw the chart
                chartInstance.update();
            })
            .catch(error => {
                console.error('Error refreshing chart data:', error);
            });
    }, interval);
}

// Initialize charts when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // This can be used to automatically initialize charts on page load
    // Example usage in page-specific scripts:
    //
    // // Create a budget overview chart
    // loadChartData('budgetOverviewChart', 'bar', 'budget_by_department');
    //
    // // Create an expense category chart
    // loadChartData('expenseCategoryChart', 'doughnut', 'expense_by_category');
    //
    // // Create a utilization gauge
    // createGaugeChart('utilizationGauge', 65);
});
