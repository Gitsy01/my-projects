/**
 * University Budget Management System
 * Main JavaScript file
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips and popovers
    initializeBootstrapComponents();
    
    // Set up dynamic form behaviors
    setupFormBehaviors();
    
    // Add auto-dismissing alert functionality
    setupAlertDismissal();
    
    // Highlight active navigation items
    highlightActiveNavigation();
    
    // Format currency inputs
    formatCurrencyInputs();
});

/**
 * Initialize Bootstrap components like tooltips and popovers
 */
function initializeBootstrapComponents() {
    // Initialize all tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize all popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

/**
 * Set up dynamic form behaviors and validations
 */
function setupFormBehaviors() {
    // Add custom validation for budget forms
    const budgetForms = document.querySelectorAll('form[action*="budgets"]');
    budgetForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            const amountInput = form.querySelector('input[name="amount"]');
            if (amountInput && parseFloat(amountInput.value) <= 0) {
                event.preventDefault();
                const errorDiv = document.createElement('div');
                errorDiv.className = 'invalid-feedback d-block';
                errorDiv.textContent = 'Budget amount must be greater than zero.';
                
                // Remove existing error message if any
                const existingError = amountInput.parentNode.querySelector('.invalid-feedback');
                if (existingError) {
                    existingError.remove();
                }
                
                amountInput.parentNode.appendChild(errorDiv);
                amountInput.classList.add('is-invalid');
            }
        });
    });
    
    // Dynamic fiscal year selection for budget creation
    const fiscalYearSelect = document.querySelector('select[name="fiscal_year_id"]');
    if (fiscalYearSelect) {
        fiscalYearSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const fiscalYearInfo = document.getElementById('fiscal-year-info');
            
            if (fiscalYearInfo && selectedOption.value) {
                // This would typically fetch fiscal year details from the server
                // For demo purposes, we'll just update the text
                fiscalYearInfo.textContent = `Selected Fiscal Year: ${selectedOption.textContent}`;
                fiscalYearInfo.style.display = 'block';
            }
        });
    }
    
    // Department and Budget cascade selection for expenses
    const departmentSelect = document.querySelector('select[name="department_id"]');
    const budgetSelect = document.querySelector('select[name="budget_id"]');
    if (departmentSelect && budgetSelect) {
        // This functionality is handled in the specific templates
        // (expense/create.html and expense/edit.html)
    }
}

/**
 * Set up auto-dismissing alerts after a certain time period
 */
function setupAlertDismissal() {
    // Auto dismiss success and info alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-success, .alert-info');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

/**
 * Highlight active navigation items based on current URL
 */
function highlightActiveNavigation() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentPath.includes(href) && href !== '/') {
            link.classList.add('active');
            
            // If it's in a dropdown, also highlight the dropdown toggle
            const dropdownParent = link.closest('.dropdown');
            if (dropdownParent) {
                const dropdownToggle = dropdownParent.querySelector('.dropdown-toggle');
                if (dropdownToggle) {
                    dropdownToggle.classList.add('active');
                }
            }
        }
    });
}

/**
 * Format currency inputs to show dollar sign and decimal places
 */
function formatCurrencyInputs() {
    const currencyInputs = document.querySelectorAll('input[name="amount"]');
    currencyInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const value = parseFloat(this.value);
            if (!isNaN(value)) {
                this.value = value.toFixed(2);
            }
        });
    });
}

/**
 * Handles confirmation dialogs for dangerous actions
 * @param {string} message - The confirmation message to display
 * @returns {boolean} - True if confirmed, false otherwise
 */
function confirmAction(message) {
    return confirm(message);
}

/**
 * Print the current page/report
 */
function printReport() {
    window.print();
}

/**
 * Export table data to CSV format
 * @param {string} tableId - The ID of the table to export
 * @param {string} filename - The name of the file to download
 */
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            // Get the text content and clean it up
            let data = cols[j].textContent.replace(/(\r\n|\n|\r)/gm, '').trim();
            
            // Escape quotes and wrap in quotes if it contains commas or quotes
            if (data.includes(',') || data.includes('"')) {
                data = '"' + data.replace(/"/g, '""') + '"';
            }
            
            row.push(data);
        }
        
        csv.push(row.join(','));
    }
    
    // Download the CSV file
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, filename);
    } else {
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}
