from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app import db
from models import Budget, Expense, Department, FiscalYear, BudgetCategory
from forms import ReportFilterForm
from sqlalchemy import func
from datetime import datetime

reports_bp = Blueprint('reports', __name__, url_prefix='/reports')

@reports_bp.route('/')
@login_required
def index():
    form = ReportFilterForm()
    
    # Populate select fields
    form.fiscal_year_id.choices = [(0, 'All')] + [(fy.id, fy.name) for fy in FiscalYear.query.all()]
    form.department_id.choices = [(0, 'All')] + [(d.id, d.name) for d in Department.query.all()]
    form.category_id.choices = [(0, 'All')] + [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    return render_template('reports/index.html', title='Financial Reports', form=form)

@reports_bp.route('/budget_vs_actual')
@login_required
def budget_vs_actual():
    fiscal_year_id = request.args.get('fiscal_year_id', type=int)
    department_id = request.args.get('department_id', type=int)
    category_id = request.args.get('category_id', type=int)
    
    form = ReportFilterForm()
    
    # Populate select fields
    form.fiscal_year_id.choices = [(0, 'All')] + [(fy.id, fy.name) for fy in FiscalYear.query.all()]
    form.department_id.choices = [(0, 'All')] + [(d.id, d.name) for d in Department.query.all()]
    form.category_id.choices = [(0, 'All')] + [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    # Set form values from request args
    if fiscal_year_id:
        form.fiscal_year_id.data = fiscal_year_id
    if department_id:
        form.department_id.data = department_id
    if category_id:
        form.category_id.data = category_id
    
    # Build the query for approved budgets
    budget_query = db.session.query(
        Budget.department_id,
        Budget.category_id,
        func.sum(Budget.amount).label('total_budget')
    ).filter(Budget.status == 'approved')
    
    # Build the query for approved expenses
    expense_query = db.session.query(
        Expense.department_id,
        Expense.category_id,
        func.sum(Expense.amount).label('total_expense')
    ).filter(Expense.status == 'approved')
    
    # Apply filters if provided
    if fiscal_year_id:
        budget_query = budget_query.filter(Budget.fiscal_year_id == fiscal_year_id)
    if department_id:
        budget_query = budget_query.filter(Budget.department_id == department_id)
        expense_query = expense_query.filter(Expense.department_id == department_id)
    if category_id:
        budget_query = budget_query.filter(Budget.category_id == category_id)
        expense_query = expense_query.filter(Expense.category_id == category_id)
    
    # Group by department and category
    budget_data = budget_query.group_by(Budget.department_id, Budget.category_id).all()
    expense_data = expense_query.group_by(Expense.department_id, Expense.category_id).all()
    
    # Convert query results to dict for easy lookup
    budget_dict = {(b.department_id, b.category_id): b.total_budget for b in budget_data}
    expense_dict = {(e.department_id, e.category_id): e.total_expense for e in expense_data}
    
    # Combine data for the report
    combined_data = []
    
    # Get all unique department-category combinations
    all_keys = set(budget_dict.keys()) | set(expense_dict.keys())
    
    # Get department and category names
    departments = {d.id: d.name for d in Department.query.all()}
    categories = {c.id: c.name for c in BudgetCategory.query.all()}
    
    for dept_id, cat_id in all_keys:
        budget_amount = float(budget_dict.get((dept_id, cat_id), 0))
        expense_amount = float(expense_dict.get((dept_id, cat_id), 0))
        remaining = budget_amount - expense_amount
        utilization = (expense_amount / budget_amount * 100) if budget_amount > 0 else 0
        
        combined_data.append({
            'department': departments.get(dept_id, 'Unknown'),
            'category': categories.get(cat_id, 'Unknown'),
            'budget': budget_amount,
            'expense': expense_amount,
            'remaining': remaining,
            'utilization': utilization
        })
    
    # Sort data by department and then category
    combined_data.sort(key=lambda x: (x['department'], x['category']))
    
    # Calculate totals
    total_budget = sum(item['budget'] for item in combined_data)
    total_expense = sum(item['expense'] for item in combined_data)
    total_remaining = total_budget - total_expense
    total_utilization = (total_expense / total_budget * 100) if total_budget > 0 else 0
    
    # Get fiscal year details if filtered
    fiscal_year = None
    if fiscal_year_id:
        fiscal_year = FiscalYear.query.get(fiscal_year_id)
    
    return render_template('reports/budget_vs_actual.html', 
                          title='Budget vs. Actual Report',
                          data=combined_data,
                          total_budget=total_budget,
                          total_expense=total_expense,
                          total_remaining=total_remaining,
                          total_utilization=total_utilization,
                          fiscal_year=fiscal_year,
                          form=form)

@reports_bp.route('/department_comparison')
@login_required
def department_comparison():
    fiscal_year_id = request.args.get('fiscal_year_id', type=int)
    
    form = ReportFilterForm()
    
    # Populate fiscal year select field
    form.fiscal_year_id.choices = [(0, 'All')] + [(fy.id, fy.name) for fy in FiscalYear.query.all()]
    
    # Set form values from request args
    if fiscal_year_id:
        form.fiscal_year_id.data = fiscal_year_id
    
    # Get all departments
    departments = Department.query.all()
    
    # Build query for budgets by department
    budget_query = db.session.query(
        Budget.department_id,
        func.sum(Budget.amount).label('total_budget')
    ).filter(Budget.status == 'approved')
    
    # Build query for expenses by department
    expense_query = db.session.query(
        Expense.department_id,
        func.sum(Expense.amount).label('total_expense')
    ).filter(Expense.status == 'approved')
    
    # Apply fiscal year filter if provided
    if fiscal_year_id:
        budget_query = budget_query.filter(Budget.fiscal_year_id == fiscal_year_id)
    
    # Group by department
    budget_data = budget_query.group_by(Budget.department_id).all()
    expense_data = expense_query.group_by(Expense.department_id).all()
    
    # Convert query results to dict for easy lookup
    budget_dict = {b.department_id: float(b.total_budget) for b in budget_data}
    expense_dict = {e.department_id: float(e.total_expense) for e in expense_data}
    
    # Prepare data for charts
    department_names = [dept.name for dept in departments]
    budget_amounts = [budget_dict.get(dept.id, 0) for dept in departments]
    expense_amounts = [expense_dict.get(dept.id, 0) for dept in departments]
    utilization_rates = [(expense_dict.get(dept.id, 0) / budget_dict.get(dept.id, 1) * 100) for dept in departments]
    
    # Get fiscal year details if filtered
    fiscal_year = None
    if fiscal_year_id:
        fiscal_year = FiscalYear.query.get(fiscal_year_id)
    
    return render_template('reports/department_comparison.html',
                          title='Department Comparison Report',
                          departments=departments,
                          department_names=department_names,
                          budget_amounts=budget_amounts,
                          expense_amounts=expense_amounts,
                          utilization_rates=utilization_rates,
                          fiscal_year=fiscal_year,
                          form=form)

@reports_bp.route('/api/chart_data')
@login_required
def chart_data():
    chart_type = request.args.get('type')
    fiscal_year_id = request.args.get('fiscal_year_id', type=int)
    
    if chart_type == 'budget_by_department':
        # Query for budget amount by department
        query = db.session.query(
            Department.name,
            func.sum(Budget.amount).label('amount')
        ).join(Budget).filter(Budget.status == 'approved')
        
        if fiscal_year_id:
            query = query.filter(Budget.fiscal_year_id == fiscal_year_id)
        
        data = query.group_by(Department.name).all()
        
        return jsonify({
            'labels': [item[0] for item in data],
            'datasets': [{
                'label': 'Budget Amount',
                'data': [float(item[1]) for item in data],
                'backgroundColor': 'rgba(54, 162, 235, 0.5)',
                'borderColor': 'rgba(54, 162, 235, 1)',
                'borderWidth': 1
            }]
        })
    
    elif chart_type == 'expense_by_category':
        # Query for expense amount by category
        query = db.session.query(
            BudgetCategory.name,
            func.sum(Expense.amount).label('amount')
        ).join(Expense).filter(Expense.status == 'approved')
        
        data = query.group_by(BudgetCategory.name).all()
        
        return jsonify({
            'labels': [item[0] for item in data],
            'datasets': [{
                'label': 'Expense Amount',
                'data': [float(item[1]) for item in data],
                'backgroundColor': [
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(153, 102, 255, 0.5)'
                ],
                'borderColor': [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                'borderWidth': 1
            }]
        })
    
    return jsonify({'error': 'Invalid chart type'})
