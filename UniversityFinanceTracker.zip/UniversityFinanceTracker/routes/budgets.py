from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from models import Budget, Department, FiscalYear, BudgetCategory
from forms import BudgetForm
from sqlalchemy import desc

budgets_bp = Blueprint('budgets', __name__, url_prefix='/budgets')

@budgets_bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    department_id = request.args.get('department_id', type=int)
    fiscal_year_id = request.args.get('fiscal_year_id', type=int)
    category_id = request.args.get('category_id', type=int)
    
    query = Budget.query
    
    if department_id:
        query = query.filter_by(department_id=department_id)
    if fiscal_year_id:
        query = query.filter_by(fiscal_year_id=fiscal_year_id)
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    budgets = query.order_by(desc(Budget.created_at)).paginate(page=page, per_page=10)
    departments = Department.query.all()
    fiscal_years = FiscalYear.query.all()
    categories = BudgetCategory.query.all()
    
    return render_template(
        'budget/index.html',
        title='Budget Management',
        budgets=budgets,
        departments=departments,
        fiscal_years=fiscal_years,
        categories=categories
    )

@budgets_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    form = BudgetForm()
    
    # Populate select fields
    form.department_id.choices = [(d.id, d.name) for d in Department.query.all()]
    form.fiscal_year_id.choices = [(fy.id, fy.name) for fy in FiscalYear.query.all()]
    form.category_id.choices = [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    if form.validate_on_submit():
        budget = Budget(
            amount=form.amount.data,
            description=form.description.data,
            department_id=form.department_id.data,
            fiscal_year_id=form.fiscal_year_id.data,
            category_id=form.category_id.data,
            created_by=current_user.id,
            status='draft'
        )
        db.session.add(budget)
        db.session.commit()
        flash('Budget has been created successfully.', 'success')
        return redirect(url_for('budgets.index'))
    
    return render_template('budget/create.html', title='Create Budget', form=form)

@budgets_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    budget = Budget.query.get_or_404(id)
    
    # Check if the current user can edit this budget
    if budget.status != 'draft' and current_user.id != budget.created_by and current_user.role != 'admin':
        flash('You cannot edit this budget.', 'danger')
        return redirect(url_for('budgets.index'))
    
    form = BudgetForm(obj=budget)
    
    # Populate select fields
    form.department_id.choices = [(d.id, d.name) for d in Department.query.all()]
    form.fiscal_year_id.choices = [(fy.id, fy.name) for fy in FiscalYear.query.all()]
    form.category_id.choices = [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    if form.validate_on_submit():
        budget.amount = form.amount.data
        budget.description = form.description.data
        budget.department_id = form.department_id.data
        budget.fiscal_year_id = form.fiscal_year_id.data
        budget.category_id = form.category_id.data
        
        db.session.commit()
        flash('Budget has been updated successfully.', 'success')
        return redirect(url_for('budgets.index'))
    
    return render_template('budget/edit.html', title='Edit Budget', form=form, budget=budget)

@budgets_bp.route('/<int:id>/view')
@login_required
def view(id):
    budget = Budget.query.get_or_404(id)
    return render_template('budget/view.html', title='View Budget', budget=budget)

@budgets_bp.route('/<int:id>/submit', methods=['POST'])
@login_required
def submit(id):
    budget = Budget.query.get_or_404(id)
    
    # Check if the current user can submit this budget
    if budget.status != 'draft' or current_user.id != budget.created_by:
        flash('You cannot submit this budget.', 'danger')
        return redirect(url_for('budgets.index'))
    
    budget.status = 'submitted'
    db.session.commit()
    flash('Budget has been submitted for approval.', 'success')
    return redirect(url_for('budgets.index'))

@budgets_bp.route('/<int:id>/approve', methods=['POST'])
@login_required
def approve(id):
    budget = Budget.query.get_or_404(id)
    
    # Check if the current user can approve this budget
    if budget.status != 'submitted' or current_user.role not in ['admin', 'financial_manager']:
        flash('You cannot approve this budget.', 'danger')
        return redirect(url_for('budgets.view', id=id))
    
    budget.status = 'approved'
    budget.approved_by = current_user.id
    db.session.commit()
    flash('Budget has been approved.', 'success')
    return redirect(url_for('budgets.view', id=id))

@budgets_bp.route('/<int:id>/reject', methods=['POST'])
@login_required
def reject(id):
    budget = Budget.query.get_or_404(id)
    
    # Check if the current user can reject this budget
    if budget.status != 'submitted' or current_user.role not in ['admin', 'financial_manager']:
        flash('You cannot reject this budget.', 'danger')
        return redirect(url_for('budgets.view', id=id))
    
    budget.status = 'rejected'
    db.session.commit()
    flash('Budget has been rejected.', 'warning')
    return redirect(url_for('budgets.view', id=id))

@budgets_bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    budget = Budget.query.get_or_404(id)
    
    # Check if the current user can delete this budget
    if budget.status not in ['draft', 'rejected'] or (current_user.id != budget.created_by and current_user.role != 'admin'):
        flash('You cannot delete this budget.', 'danger')
        return redirect(url_for('budgets.index'))
    
    db.session.delete(budget)
    db.session.commit()
    flash('Budget has been deleted.', 'success')
    return redirect(url_for('budgets.index'))
