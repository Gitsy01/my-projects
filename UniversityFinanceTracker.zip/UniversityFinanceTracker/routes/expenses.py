from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from models import Expense, Budget, Department, BudgetCategory
from forms import ExpenseForm
from sqlalchemy import desc
from datetime import datetime

expenses_bp = Blueprint('expenses', __name__, url_prefix='/expenses')

@expenses_bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    department_id = request.args.get('department_id', type=int)
    budget_id = request.args.get('budget_id', type=int)
    category_id = request.args.get('category_id', type=int)
    status = request.args.get('status')
    
    query = Expense.query
    
    if department_id:
        query = query.filter_by(department_id=department_id)
    if budget_id:
        query = query.filter_by(budget_id=budget_id)
    if category_id:
        query = query.filter_by(category_id=category_id)
    if status:
        query = query.filter_by(status=status)
    
    expenses = query.order_by(desc(Expense.date)).paginate(page=page, per_page=10)
    departments = Department.query.all()
    budgets = Budget.query.all()
    categories = BudgetCategory.query.all()
    
    return render_template(
        'expense/index.html',
        title='Expense Management',
        expenses=expenses,
        departments=departments,
        budgets=budgets,
        categories=categories
    )

@expenses_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    form = ExpenseForm()
    
    # Populate select fields
    form.department_id.choices = [(d.id, d.name) for d in Department.query.all()]
    form.budget_id.choices = [(b.id, f"{b.department.name} - {b.category.name} - {b.fiscal_year.name}") 
                             for b in Budget.query.filter_by(status='approved').all()]
    form.category_id.choices = [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    if form.validate_on_submit():
        # Check if budget has enough funds
        budget = Budget.query.get(form.budget_id.data)
        
        if budget:
            # Calculate total expenses for this budget
            total_expenses = sum([expense.amount for expense in budget.expenses])
            
            # Check if adding this expense would exceed the budget
            if total_expenses + form.amount.data > budget.amount:
                flash('This expense would exceed the budget limit.', 'danger')
                return render_template('expense/create.html', title='Create Expense', form=form)
            
            expense = Expense(
                amount=form.amount.data,
                description=form.description.data,
                date=form.date.data,
                receipt_number=form.receipt_number.data,
                department_id=form.department_id.data,
                budget_id=form.budget_id.data,
                category_id=form.category_id.data,
                created_by=current_user.id,
                status='pending'
            )
            db.session.add(expense)
            db.session.commit()
            flash('Expense has been created successfully.', 'success')
            return redirect(url_for('expenses.index'))
        else:
            flash('Invalid budget selected.', 'danger')
    
    return render_template('expense/create.html', title='Create Expense', form=form)

@expenses_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    expense = Expense.query.get_or_404(id)
    
    # Check if the current user can edit this expense
    if expense.status != 'pending' and current_user.id != expense.created_by and current_user.role != 'admin':
        flash('You cannot edit this expense.', 'danger')
        return redirect(url_for('expenses.index'))
    
    form = ExpenseForm(obj=expense)
    
    # Populate select fields
    form.department_id.choices = [(d.id, d.name) for d in Department.query.all()]
    form.budget_id.choices = [(b.id, f"{b.department.name} - {b.category.name} - {b.fiscal_year.name}") 
                             for b in Budget.query.filter_by(status='approved').all()]
    form.category_id.choices = [(c.id, c.name) for c in BudgetCategory.query.all()]
    
    if form.validate_on_submit():
        # Check if budget has enough funds (excluding this expense's current amount)
        budget = Budget.query.get(form.budget_id.data)
        
        if budget:
            # Calculate total expenses for this budget excluding the current expense
            total_expenses = sum([exp.amount for exp in budget.expenses if exp.id != expense.id])
            
            # Check if updating this expense would exceed the budget
            if total_expenses + form.amount.data > budget.amount:
                flash('This expense would exceed the budget limit.', 'danger')
                return render_template('expense/edit.html', title='Edit Expense', form=form, expense=expense)
            
            expense.amount = form.amount.data
            expense.description = form.description.data
            expense.date = form.date.data
            expense.receipt_number = form.receipt_number.data
            expense.department_id = form.department_id.data
            expense.budget_id = form.budget_id.data
            expense.category_id = form.category_id.data
            
            db.session.commit()
            flash('Expense has been updated successfully.', 'success')
            return redirect(url_for('expenses.index'))
        else:
            flash('Invalid budget selected.', 'danger')
    
    return render_template('expense/edit.html', title='Edit Expense', form=form, expense=expense)

@expenses_bp.route('/<int:id>/approve', methods=['POST'])
@login_required
def approve(id):
    expense = Expense.query.get_or_404(id)
    
    # Check if the current user can approve this expense
    if expense.status != 'pending' or current_user.role not in ['admin', 'financial_manager']:
        flash('You cannot approve this expense.', 'danger')
        return redirect(url_for('expenses.index'))
    
    # Check if budget has enough funds
    budget = expense.budget
    total_expenses = sum([exp.amount for exp in budget.expenses if exp.status == 'approved'])
    
    if total_expenses + expense.amount > budget.amount:
        flash('Approving this expense would exceed the budget limit.', 'danger')
        return redirect(url_for('expenses.index'))
    
    expense.status = 'approved'
    expense.approved_by = current_user.id
    db.session.commit()
    flash('Expense has been approved.', 'success')
    return redirect(url_for('expenses.index'))

@expenses_bp.route('/<int:id>/reject', methods=['POST'])
@login_required
def reject(id):
    expense = Expense.query.get_or_404(id)
    
    # Check if the current user can reject this expense
    if expense.status != 'pending' or current_user.role not in ['admin', 'financial_manager']:
        flash('You cannot reject this expense.', 'danger')
        return redirect(url_for('expenses.index'))
    
    expense.status = 'rejected'
    db.session.commit()
    flash('Expense has been rejected.', 'warning')
    return redirect(url_for('expenses.index'))

@expenses_bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    expense = Expense.query.get_or_404(id)
    
    # Check if the current user can delete this expense
    if expense.status != 'pending' and current_user.role != 'admin':
        flash('You cannot delete this expense.', 'danger')
        return redirect(url_for('expenses.index'))
    
    db.session.delete(expense)
    db.session.commit()
    flash('Expense has been deleted.', 'success')
    return redirect(url_for('expenses.index'))
