from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from models import Department, User
from forms import DepartmentForm
from sqlalchemy import desc

departments_bp = Blueprint('departments', __name__, url_prefix='/departments')

@departments_bp.route('/')
@login_required
def index():
    page = request.args.get('page', 1, type=int)
    departments = Department.query.order_by(desc(Department.created_at)).paginate(page=page, per_page=10)
    return render_template('department/index.html', title='Department Management', departments=departments)

@departments_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    # Check if user has admin privileges
    if current_user.role != 'admin':
        flash('You do not have permission to create departments.', 'danger')
        return redirect(url_for('departments.index'))
    
    form = DepartmentForm()
    
    # Populate department head choices
    form.head_id.choices = [(0, 'None')] + [(u.id, u.username) for u in User.query.filter(User.role.in_(['admin', 'department_head'])).all()]
    
    if form.validate_on_submit():
        # Check if department code already exists
        existing_department = Department.query.filter_by(code=form.code.data).first()
        if existing_department:
            flash('Department code already exists.', 'danger')
            return render_template('department/create.html', title='Create Department', form=form)
        
        department = Department(
            name=form.name.data,
            code=form.code.data,
            description=form.description.data
        )
        
        # Set department head if one was selected
        if form.head_id.data and form.head_id.data > 0:
            department.head_id = form.head_id.data
        
        db.session.add(department)
        db.session.commit()
        flash('Department has been created successfully.', 'success')
        return redirect(url_for('departments.index'))
    
    return render_template('department/create.html', title='Create Department', form=form)

@departments_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    # Check if user has admin privileges
    if current_user.role != 'admin':
        flash('You do not have permission to edit departments.', 'danger')
        return redirect(url_for('departments.index'))
    
    department = Department.query.get_or_404(id)
    form = DepartmentForm(obj=department)
    
    # Populate department head choices
    form.head_id.choices = [(0, 'None')] + [(u.id, u.username) for u in User.query.filter(User.role.in_(['admin', 'department_head'])).all()]
    
    if form.validate_on_submit():
        # Check if department code already exists and is not this department
        existing_department = Department.query.filter_by(code=form.code.data).first()
        if existing_department and existing_department.id != id:
            flash('Department code already exists.', 'danger')
            return render_template('department/edit.html', title='Edit Department', form=form, department=department)
        
        department.name = form.name.data
        department.code = form.code.data
        department.description = form.description.data
        
        # Set department head if one was selected
        if form.head_id.data and form.head_id.data > 0:
            department.head_id = form.head_id.data
        else:
            department.head_id = None
        
        db.session.commit()
        flash('Department has been updated successfully.', 'success')
        return redirect(url_for('departments.index'))
    
    return render_template('department/edit.html', title='Edit Department', form=form, department=department)

@departments_bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    # Check if user has admin privileges
    if current_user.role != 'admin':
        flash('You do not have permission to delete departments.', 'danger')
        return redirect(url_for('departments.index'))
    
    department = Department.query.get_or_404(id)
    
    # Check if department has associated budgets or expenses
    if department.budgets or department.expenses:
        flash('Cannot delete department with associated budgets or expenses.', 'danger')
        return redirect(url_for('departments.index'))
    
    db.session.delete(department)
    db.session.commit()
    flash('Department has been deleted.', 'success')
    return redirect(url_for('departments.index'))
